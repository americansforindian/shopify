<?php get_header(); ?>
<?php trendz_template_part( 'post', 'templates/post' ); ?>
<?php get_footer(); ?>