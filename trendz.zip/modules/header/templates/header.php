<header id="header">
    <?php echo apply_filters( 'trendz_header_get_template_part', trendz_get_template_part( 'header', 'templates/header-content' ) ); ?>
</header>