<footer id="footer">
    <div class="container">
        <div class="wdt-no-footer-builder-content footer-copyright aligncenter">
            <span><?php echo esc_html__('Copyright', 'trendz'); ?> &copy; <?php echo date('Y') .' '.get_bloginfo('title'); ?></span>
        </div>
    </div>
</footer>