<?php
echo apply_filters( 'trendz_404_get_template_part', trendz_get_template_part( '404', 'templates/404', '', trendz_404_page_params() ) );
?>