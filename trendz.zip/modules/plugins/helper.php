<?php

if ( is_admin() ) {
	require_once TRENDZ_MODULE_DIR . '/plugins/class-tgm-plugin-activation.php';
	require_once TRENDZ_MODULE_DIR . '/plugins/tgm-plugin-activation.php';
}