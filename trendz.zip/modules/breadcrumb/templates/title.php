<?php
echo apply_filters( 'trendz_breadcrumb_get_template_part', trendz_get_template_part( 'breadcrumb', 'templates/title-content', '',trendz_breadcrumb_params() ), trendz_get_page_id() ); ?>