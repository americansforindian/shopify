===== Trendz Shop =====

Trendz Shop plugin adds shop features for Trendz theme.


== Changelog ==

= 1.0.0 =

    * First release!