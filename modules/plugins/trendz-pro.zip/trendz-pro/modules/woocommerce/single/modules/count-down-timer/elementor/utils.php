<?php

/*
* Update Summary - Options Filter
*/

if( ! function_exists( 'trendz_shop_woo_single_summary_options_ctrendz_render' ) ) {
	function trendz_shop_woo_single_summary_options_ctrendz_render( $options ) {

		$options['countdown'] = esc_html__('Summary Count Down', 'trendz-pro');
		return $options;

	}
	add_filter( 'trendz_shop_woo_single_summary_options', 'trendz_shop_woo_single_summary_options_ctrendz_render', 10, 1 );

}

/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'trendz_shop_woo_single_summary_styles_ctrendz_render' ) ) {
	function trendz_shop_woo_single_summary_styles_ctrendz_render( $styles ) {

		array_push( $styles, 'wdt-shop-coundown-timer' );
		return $styles;

	}
	add_filter( 'trendz_shop_woo_single_summary_styles', 'trendz_shop_woo_single_summary_styles_ctrendz_render', 10, 1 );

}

/*
* Update Summary - Scripts Filter
*/

if( ! function_exists( 'trendz_shop_woo_single_summary_scripts_ctrendz_render' ) ) {
	function trendz_shop_woo_single_summary_scripts_ctrendz_render( $scripts ) {

		array_push( $scripts, 'jquery-downcount' );
		array_push( $scripts, 'wdt-shop-coundown-timer' );
		return $scripts;

	}
	add_filter( 'trendz_shop_woo_single_summary_scripts', 'trendz_shop_woo_single_summary_scripts_ctrendz_render', 10, 1 );

}