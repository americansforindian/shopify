===== Trendz Pro =====

Trendz Pro plugin adds advanced features for Trendz theme.


== Changelog ==

= 1.0.0 =

    * First release!