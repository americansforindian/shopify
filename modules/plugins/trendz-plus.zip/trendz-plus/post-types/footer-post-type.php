<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if (! class_exists ( 'TrendzPlusFooterPostType' ) ) {

	class TrendzPlusFooterPostType {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

		function __construct() {

			add_action ( 'init', array( $this, 'trendz_register_cpt' ) );
			add_filter ( 'template_include', array ( $this, 'trendz_template_include' ) );
		}

		function trendz_register_cpt() {

			$labels = array (
				'name'				 => __( 'Footers', 'trendz-plus' ),
				'singular_name'		 => __( 'Footer', 'trendz-plus' ),
				'menu_name'			 => __( 'Footers', 'trendz-plus' ),
				'add_new'			 => __( 'Add Footer', 'trendz-plus' ),
				'add_new_item'		 => __( 'Add New Footer', 'trendz-plus' ),
				'edit'				 => __( 'Edit Footer', 'trendz-plus' ),
				'edit_item'			 => __( 'Edit Footer', 'trendz-plus' ),
				'new_item'			 => __( 'New Footer', 'trendz-plus' ),
				'view'				 => __( 'View Footer', 'trendz-plus' ),
				'view_item' 		 => __( 'View Footer', 'trendz-plus' ),
				'search_items' 		 => __( 'Search Footers', 'trendz-plus' ),
				'not_found' 		 => __( 'No Footers found', 'trendz-plus' ),
				'not_found_in_trash' => __( 'No Footers found in Trash', 'trendz-plus' ),
			);

			$args = array (
				'labels' 				=> $labels,
				'public' 				=> true,
				'exclude_from_search'	=> true,
				'show_in_nav_menus' 	=> false,
				'show_in_rest' 			=> true,
				'menu_position'			=> 26,
				'menu_icon' 			=> 'dashicons-editor-insertmore',
				'hierarchical' 			=> false,
				'supports' 				=> array ( 'title', 'editor', 'revisions' ),
			);

			register_post_type ( 'wdt_footers', $args );
		}

		function trendz_template_include($template) {
			if ( is_singular( 'wdt_footers' ) ) {
				if ( ! file_exists ( get_stylesheet_directory () . '/single-wdt_footers.php' ) ) {
					$template = TRENDZ_PLUS_DIR_PATH . 'post-types/templates/single-wdt_footers.php';
				}
			}

			return $template;
		}
	}
}

TrendzPlusFooterPostType::instance();