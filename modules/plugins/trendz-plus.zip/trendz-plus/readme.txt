======= Trendz Plus =====

Trendz Plus plugin adds additonal features for Trendz theme.


== Changelog ==

= 1.0.0 =

    * First release!