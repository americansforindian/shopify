<div class="pre-loader loader1">
    <div class="loader-inner">
        <span class="loader-text">Loading..</span>
    </div>
</div>