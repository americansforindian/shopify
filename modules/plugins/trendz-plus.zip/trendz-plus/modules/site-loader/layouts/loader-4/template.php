<div class="pre-loader loader4">
    <div class="loader-inner">
        <span class="loader-text">
            <img class="pre_loader_image" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" src="<?php echo trendz_customizer_settings('site_loader_image');?>"/>
        </span>
    </div>
</div>