<div class="pre-loader loader3">
    <div class="loader-inner">
        <span class="loader-text"><img class="pre_loader_image" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" src="<?php echo esc_url(TRENDZ_PLUS_DIR_URL.'modules/site-loader/layouts/loader-3/assets/image/trendz-loader-image.gif'); ?>"/></span>
    </div>
</div>